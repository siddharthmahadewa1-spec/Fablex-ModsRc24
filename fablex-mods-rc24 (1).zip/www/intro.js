(function(){'use strict';
const $=s=>document.querySelector(s);
function insets(){try{if(window.FXInsets){const r=document.documentElement.style;r.setProperty('--sat',window.FXInsets.top()+'px');r.setProperty('--sab',window.FXInsets.bottom()+'px');}}catch(e){}}
insets();[150,600,1500,3000].forEach(t=>setTimeout(insets,t));addEventListener('resize',insets);let done=false,sound='',trying=false;
for(let i=0;i<14;i++){const d=document.createElement('i');d.style.left=(Math.random()*100)+'%';d.style.animationDuration=(9+Math.random()*9)+'s';d.style.animationDelay=(-Math.random()*12)+'s';d.style.opacity=.25+Math.random()*.5;$('#dots').appendChild(d);}
const GEV=['pointerdown','touchstart','keydown'];
function leave(){if(done)return;done=true;GEV.forEach(t=>removeEventListener(t,gesture,true));const i=$('#intro');i.classList.add('out');setTimeout(()=>i.remove(),900);}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');setTimeout(()=>t.classList.remove('on'),4800);}
// ---- sound: HTML audio first, Web Audio (decoded from the embedded data) as backup ----
const src=window.FX_AUDIO||'open.mp3',au=new Audio(src);au.preload='auto';let ctx=null,buf=null,wantWA=false;
function prepWA(){if(ctx||!/^data:/.test(src))return;try{const C=window.AudioContext||window.webkitAudioContext;ctx=new C();const s=atob(src.split(',')[1]),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);ctx.decodeAudioData(u.buffer,b=>{buf=b;if(wantWA)playWA();},()=>{});}catch(e){}}
function playWA(){wantWA=true;if(!buf||!ctx)return;wantWA=false;try{if(ctx.resume)ctx.resume();const s=ctx.createBufferSource();s.buffer=buf;s.connect(ctx.destination);s.start(0);sound='webaudio';window.__fxs=sound;}catch(e){}trying=false;}
function startSound(){if(sound||trying)return;trying=true;au.currentTime=0;let p;try{p=au.play();}catch(e){}if(p&&p.then)p.then(()=>{sound='html';window.__fxs=sound;trying=false;}).catch(()=>{prepWA();playWA();trying=false;});else{prepWA();playWA();}}
function gesture(){if(!sound)startSound();}
prepWA();
setTimeout(()=>{$('#intro').classList.add('live');startSound();},350);
GEV.forEach(t=>addEventListener(t,gesture,true));
let leaveT=setTimeout(leave,5000);
// ---- links ----
function openLink(url){const P=window.Capacitor&&window.Capacitor.Plugins;
 const fb=()=>{if(window.Capacitor){location.href=url;return;}let w=null;try{w=window.open(url,'_blank');}catch(e){}if(!w){const m='This viewer blocks links. Open the file in Chrome, or use the APK.';let c;try{c=navigator.clipboard&&navigator.clipboard.writeText(url);}catch(e){}if(c&&c.then)c.then(()=>toast(m+' Link copied.'),()=>toast(m));else toast(m);}};
 if(P&&P.AppLauncher){P.AppLauncher.openUrl({url}).then(r=>{if(r&&r.completed===false)throw 0;}).catch(()=>{P.Browser?P.Browser.open({url}).catch(fb):fb();});}else if(P&&P.Browser){P.Browser.open({url}).catch(fb);}else fb();}
document.querySelectorAll('a[data-ext]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();clearTimeout(leaveT);openLink(a.href);}));
$('#intro').addEventListener('click',()=>{if($('#intro').classList.contains('live'))leave();});
})();
