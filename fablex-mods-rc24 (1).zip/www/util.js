(function(){'use strict';
const tick = () => new Promise(r => setTimeout(r, 30));
// ---------- zip (store) ----------
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function makeZip(files) {
  const enc = new TextEncoder(), parts = [], cen = []; let off = 0;
  for (const f of files) {
    const nm = enc.encode(f.name), crc = crc32(f.data), h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint32(14, crc, true); h.setUint32(18, f.data.length, true); h.setUint32(22, f.data.length, true); h.setUint16(26, nm.length, true);
    parts.push(new Uint8Array(h.buffer), nm, f.data);
    const c = new DataView(new ArrayBuffer(46)); c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint32(16, crc, true); c.setUint32(20, f.data.length, true); c.setUint32(24, f.data.length, true); c.setUint16(28, nm.length, true); c.setUint32(42, off, true);
    cen.push(new Uint8Array(c.buffer), nm); off += 30 + nm.length + f.data.length;
  }
  let cs = 0; for (const c of cen) cs += c.length; const e = new DataView(new ArrayBuffer(22));
  e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cs, true); e.setUint32(16, off, true);
  return new Blob([...parts, ...cen, new Uint8Array(e.buffer)]);
}
// ---------- saving ----------
const b64 = u => { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
async function writeChunks(FS, dir, path, u8) {
  const CH = 3 * 1048576; await FS.writeFile({ path, data: b64(u8.subarray(0, Math.min(CH, u8.length))), directory: dir, recursive: true });
  for (let o = CH; o < u8.length; o += CH) await FS.appendFile({ path, data: b64(u8.subarray(o, o + CH)), directory: dir });
}
async function saveFile(name, blobOrU8) {
  const u8 = blobOrU8 instanceof Blob ? new Uint8Array(await blobOrU8.arrayBuffer()) : blobOrU8;
  const cap = window.Capacitor, P = cap && cap.Plugins, FS = P && P.Filesystem;
  if (cap && cap.isNativePlatform && cap.isNativePlatform() && FS) {
    const dir = 'RC Bundle Editor'; let last;
    for (const [d, p, shown] of [['EXTERNAL_STORAGE', 'Download/' + dir + '/' + name, 'Download/' + dir + '/' + name], ['DOCUMENTS', dir + '/' + name, 'Documents/' + dir + '/' + name]]) {
      try { await writeChunks(FS, d, p, u8); return 'Saved: ' + shown; } catch (e) { last = e; }
    }
    if (P.Share) {
      try { await writeChunks(FS, 'CACHE', name, u8); const u = await FS.getUri({ path: name, directory: 'CACHE' }); await P.Share.share({ title: name, url: u.uri }); return 'Share sheet opened. Pick a file manager to save the file.'; } catch (e) { last = e; }
    }
    throw last || new Error('Could not save');
  }
  const mime = /\.zip$/i.test(name) ? 'application/zip' : /\.png$/i.test(name) ? 'image/png' : 'application/octet-stream';
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([u8], { type: mime })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 60000);
  return 'Download started: ' + name;
}
// ---------- image helpers ----------
function toCanvas(r) { const c = document.createElement('canvas'); c.width = r.W; c.height = r.H; c.getContext('2d').putImageData(new ImageData(r.rgba, r.W, r.H), 0, 0); return c; }
const pngBytes = c => new Promise(res => c.toBlob(async b => res(new Uint8Array(await b.arrayBuffer())), 'image/png'));

window.U = { makeZip, saveFile, toCanvas, pngBytes, tick, crc32 };
})();
