(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.RC = factory(); })(typeof self !== 'undefined' ? self : this, function () {
'use strict';
const M32 = 4294967295;
// ---------------- LZ4 ----------------
function lz4(src, usize) {
  const out = new Uint8Array(usize); let i = 0, o = 0; const n = src.length;
  while (i < n) {
    const t = src[i++]; let l = t >> 4;
    if (l === 15) { let b; do { b = src[i++]; l += b; } while (b === 255); }
    out.set(src.subarray(i, i + l), o); o += l; i += l; if (i >= n) break;
    const off = src[i] | (src[i + 1] << 8); i += 2; let m = t & 15;
    if (m === 15) { let b; do { b = src[i++]; m += b; } while (b === 255); }
    m += 4; let s = o - off; for (let k = 0; k < m; k++) out[o++] = out[s++];
  }
  return out;
}
// ---------------- LZMA (Unity style: 5 prop bytes + raw stream) ----------------
function lzma(src, usize) {
  const props = src[0]; const lc = props % 9, rem = (props / 9) | 0, lp = rem % 5, pb = (rem / 5) | 0;
  let pos = 5; const out = new Uint8Array(usize); let op = 0;
  let range = M32, code = 0; pos++;
  for (let i = 0; i < 4; i++) code = ((code * 256) + src[pos++]) >>> 0;
  const init = n => new Uint16Array(n).fill(1024);
  const isMatch = init(192), isRep = init(12), isRepG0 = init(12), isRepG1 = init(12), isRepG2 = init(12), isRep0Long = init(192);
  const posSlot = init(256), specPos = init(115), align = init(16), lit = init(0x300 << (lc + lp));
  const lenP = init(514), repLenP = init(514);
  function bit(p, i) {
    const v = p[i]; const bound = (range >>> 11) * v; let b;
    if (code < bound) { range = bound; p[i] = v + ((2048 - v) >> 5); b = 0; }
    else { range -= bound; code -= bound; p[i] = v - (v >> 5); b = 1; }
    if (range < 16777216) { range = (range * 256) >>> 0; code = ((code * 256) + src[pos++]) >>> 0; }
    return b;
  }
  function tree(p, base, n) { let m = 1; for (let i = 0; i < n; i++) m = (m << 1) + bit(p, base + m); return m - (1 << n); }
  function rtree(p, base, n) { let m = 1, s = 0; for (let i = 0; i < n; i++) { const b = bit(p, base + m); m = (m << 1) + b; s |= b << i; } return s; }
  function direct(n) {
    let r = 0;
    for (let i = 0; i < n; i++) {
      range = range >>> 1; let t = 0; if (code >= range) { code -= range; t = 1; }
      r = ((r << 1) | t) >>> 0;
      if (range < 16777216) { range = (range * 256) >>> 0; code = ((code * 256) + src[pos++]) >>> 0; }
    }
    return r;
  }
  function len(p, ps) {
    if (!bit(p, 0)) return tree(p, 2 + ps * 8, 3);
    if (!bit(p, 1)) return 8 + tree(p, 130 + ps * 8, 3);
    return 16 + tree(p, 258, 8);
  }
  let state = 0, rep0 = 0, rep1 = 0, rep2 = 0, rep3 = 0;
  while (op < usize) {
    const ps = op & ((1 << pb) - 1);
    if (!bit(isMatch, (state << 4) + ps)) {
      const prev = op > 0 ? out[op - 1] : 0; const base = 0x300 * (((op & ((1 << lp) - 1)) << lc) + (prev >> (8 - lc)));
      let sym = 1;
      if (state >= 7) {
        let mb = out[op - rep0 - 1];
        do { const m = (mb >> 7) & 1; mb <<= 1; const b = bit(lit, base + ((1 + m) << 8) + sym); sym = (sym << 1) | b; if (m !== b) break; } while (sym < 0x100);
      }
      while (sym < 0x100) sym = (sym << 1) | bit(lit, base + sym);
      out[op++] = sym & 255; state = state < 4 ? 0 : (state < 10 ? state - 3 : state - 6); continue;
    }
    let l;
    if (bit(isRep, state)) {
      if (!bit(isRepG0, state)) {
        if (!bit(isRep0Long, (state << 4) + ps)) { state = state < 7 ? 9 : 11; out[op] = out[op - rep0 - 1]; op++; continue; }
      } else {
        let d;
        if (!bit(isRepG1, state)) d = rep1; else { if (!bit(isRepG2, state)) d = rep2; else { d = rep3; rep3 = rep2; } rep2 = rep1; }
        rep1 = rep0; rep0 = d;
      }
      l = len(repLenP, ps); state = state < 7 ? 8 : 11;
    } else {
      rep3 = rep2; rep2 = rep1; rep1 = rep0; l = len(lenP, ps); state = state < 7 ? 7 : 10;
      const slot = tree(posSlot, (l < 4 ? l : 3) * 64, 6);
      if (slot < 4) rep0 = slot;
      else {
        const nd = (slot >> 1) - 1; rep0 = ((2 | (slot & 1)) << nd) >>> 0;
        if (slot < 14) rep0 += rtree(specPos, rep0 - slot - 1, nd);
        else { rep0 += (direct(nd - 4) << 4) >>> 0; rep0 += rtree(align, 0, 4); rep0 >>>= 0; }
      }
      if (rep0 === M32) break;
    }
    l += 2; for (let k = 0; k < l && op < usize; k++) { out[op] = out[op - rep0 - 1]; op++; }
  }
  return out;
}
function decomp(buf, comp, us) { if (comp === 0) return buf; if (comp === 1) return lzma(buf, us); if (comp === 2 || comp === 3) return lz4(buf, us); throw new Error('Unsupported bundle compression (' + comp + ')'); }
function concat(parts) { let n = 0; for (const p of parts) n += p.length; const o = new Uint8Array(n); let k = 0; for (const p of parts) { o.set(p, k); k += p.length; } return o; }
// ---------------- Unity bundle ----------------
function openBundle(u8) {
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let o = -1; const lim = Math.min(u8.length - 8, 1 << 20);
  for (let i = 0; i < lim; i++) if (u8[i] === 0x55 && u8[i + 1] === 0x6e && u8[i + 2] === 0x69 && u8[i + 3] === 0x74 && u8[i + 4] === 0x79 && u8[i + 5] === 0x46 && u8[i + 6] === 0x53) { o = i; break; }
  if (o < 0) throw new Error('This does not look like a Unity bundle (UnityFS signature not found)');
  let p = o + 8; const ver = dv.getUint32(p); p += 4;
  while (u8[p] !== 0) p++; p++; while (u8[p] !== 0) p++; p++;
  const strings = u8.slice(o + 12, p);
  p += 8; const cbi = dv.getUint32(p); p += 4; const ubi = dv.getUint32(p); p += 4; const flags = dv.getUint32(p); p += 4;
  let hdrEnd = p - o; if (ver >= 7) hdrEnd = (hdrEnd + 15) & ~15;
  const biRaw = (flags & 0x80) ? u8.subarray(u8.length - cbi) : u8.subarray(o + hdrEnd, o + hdrEnd + cbi);
  const bi = decomp(biRaw, flags & 0x3f, ubi); const bdv = new DataView(bi.buffer, bi.byteOffset, bi.byteLength);
  let q = 16; const bc = bdv.getInt32(q); q += 4; const blocks = [];
  for (let i = 0; i < bc; i++) { blocks.push([bdv.getUint32(q), bdv.getUint32(q + 4), bdv.getUint16(q + 8)]); q += 10; }
  const nc = bdv.getInt32(q); q += 4; const nodes = [];
  for (let i = 0; i < nc; i++) {
    const off = Number(bdv.getBigUint64(q)), size = Number(bdv.getBigUint64(q + 8)), fl = bdv.getUint32(q + 16); q += 20;
    let e = q; while (bi[e] !== 0) e++; nodes.push({ off, size, flags: fl, path: new TextDecoder().decode(bi.subarray(q, e)) }); q = e + 1;
  }
  let pos = o + hdrEnd + ((flags & 0x80) ? 0 : cbi);
  if ((flags & 0x200) && !(flags & 0x80)) pos = o + ((hdrEnd + cbi + 15) & ~15);
  const parts = [];
  for (const [us, cs, f] of blocks) { parts.push(decomp(u8.subarray(pos, pos + cs), f & 0x3f, us)); pos += cs; }
  const data = concat(parts); const sfLen = nodes[0].size;
  return { prefix: u8.slice(0, o), ver, strings, nodes, sf: data.slice(0, sfLen), res: data.slice(sfLen), changed: [] };
}
const ARCH = new TextEncoder().encode('archive:/');
function findBytes(a, pat) { const n = a.length - pat.length; for (let i = 0; i <= n; i++) { if (a[i] === pat[0]) { let j = 1; while (j < pat.length && a[i + j] === pat[j]) j++; if (j === pat.length) return i; } } return -1; }
function parseSF(b) {
  const sf = b.sf, dv = new DataView(sf.buffer, sf.byteOffset, sf.byteLength);
  let p = 8; const ver = dv.getUint32(p); p += 4; let doff = dv.getUint32(p); p += 4; const endian = sf[p]; p += 4; let sizePos = 0;
  if (ver >= 22) { p += 4; sizePos = p; p += 8; doff = Number(dv.getBigInt64(p)); p += 8; p += 8; }
  const le = endian === 0; while (sf[p] !== 0) p++; p++; p += 4; const ett = sf[p]; p++;
  const nt = dv.getInt32(p, le); p += 4; const types = [];
  for (let i = 0; i < nt; i++) {
    const cid = dv.getInt32(p, le); p += 7; if (cid === 114) p += 16; p += 16;
    if (ett) { const n = dv.getInt32(p, le), sb = dv.getInt32(p + 4, le); p += 8 + n * 32 + sb; const dc = dv.getInt32(p, le); p += 4 + 4 * dc; }
    types.push(cid);
  }
  const no = dv.getInt32(p, le); p += 4; const texs = []; const seen = {};
  for (let i = 0; i < no; i++) {
    p = (p + 3) & ~3; const entry = p; const bs = Number(dv.getBigInt64(p + 8, le)) + doff, size = dv.getUint32(p + 16, le), tid = dv.getInt32(p + 20, le); p += 24;
    if (types[tid] !== 28) continue;
    const ob = sf.subarray(bs, bs + size), od = new DataView(ob.buffer, ob.byteOffset, ob.byteLength);
    const n = od.getInt32(0, true); let name = new TextDecoder().decode(ob.subarray(4, 4 + n));
    let q = (4 + n + 3) & ~3; q += 6; q = (q + 3) & ~3;
    const w = od.getInt32(q, true), h = od.getInt32(q + 4, true), cis = od.getInt32(q + 8, true), fmt = od.getInt32(q + 16, true), mips = od.getInt32(q + 20, true);
    let imgPos, imgLen, dataPos, sOff = 0, sSize = 0; const k = findBytes(ob, ARCH);
    if (k >= 0) { const sp = k - 16; sOff = Number(od.getBigUint64(sp, true)); sSize = od.getUint32(sp + 8, true); imgPos = sp - 4; imgLen = od.getInt32(imgPos, true); dataPos = imgPos + 4; }
    else { const P = (cis + 3) & ~3; dataPos = ob.length - 16 - P; imgPos = dataPos - 4; imgLen = od.getInt32(imgPos, true); }
    seen[name] = (seen[name] || 0) + 1; if (seen[name] > 1) name += '_' + seen[name];
    texs.push({ name, w, h, cis, fmt, mips, entry, bs, size, q, imgPos, dataPos, imgLen, sOff, sSize, inline: sSize === 0 });
  }
  return { texs, le, doff, sizePos };
}
function rawOf(b, t) { return t.inline ? b.sf.subarray(t.bs + t.dataPos, t.bs + t.dataPos + t.imgLen) : b.res.subarray(t.sOff, t.sOff + t.sSize); }
// ---------------- Crunch (Unity) ----------------
const MOST = [17, 18, 19, 20, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15, 16];
const clog2 = v => v > 1 ? 32 - Math.clz32(v - 1) : 0;
class Model {
  constructor() { this.cs = []; }
  prepare() { const n = this.cs.length; if (n < 1 || n > 8192) return false; this.total = n; return this.init(n > 16 ? Math.min(1 + clog2(n), 11) : 0); }
  init(tb) {
    const cs = this.cs, nc = new Array(17).fill(0);
    for (const c of cs) if (c) nc[c]++;
    const maxc = new Array(17).fill(0), vp = new Array(17).fill(0), minc = new Array(16).fill(0), sp = new Array(17).fill(0);
    let cur = 0, total = 0, maxcs = 0, mincs = M32;
    for (let i = 1; i < 17; i++) {
      const n = nc[i];
      if (n === 0) maxc[i - 1] = 0;
      else {
        mincs = Math.min(mincs, i); maxcs = Math.max(maxcs, i); minc[i - 1] = cur; const mc = cur + n - 1;
        maxc[i - 1] = 1 + ((mc << (16 - i)) | ((1 << (16 - i)) - 1)); vp[i - 1] = total; sp[i] = total; cur += n; total += n;
      }
      cur <<= 1;
    }
    const order = new Array(Math.max(total, 1)).fill(0);
    for (let i = 0; i < cs.length; i++) { const c = cs[i]; if (c) { const p = sp[c]++; if (p >= total) return false; order[p] = i; } }
    if (tb <= mincs) tb = 0;
    let lookup = null;
    if (tb) {
      lookup = new Uint32Array(1 << tb).fill(M32);
      for (let cz = 1; cz <= tb; cz++) {
        if (nc[cz] === 0) continue;
        const fill = tb - cz, fn = 1 << fill, mn = minc[cz - 1], k = maxc[cz - 1], mx = k === 0 ? M32 : (k - 1) >> (16 - cz), v0 = vp[cz - 1];
        for (let code = mn; code <= mx; code++) {
          const sym = order[v0 + code - mn]; if (cs[sym] !== cz) return false;
          const base = code << fill, v = (sym | (cz << 16)) >>> 0; for (let j = 0; j < fn; j++) lookup[base + j] = v;
        }
      }
    }
    for (let i = 0; i < 16; i++) vp[i] -= minc[i];
    let tmc = 0, dsc = mincs;
    if (tb) {
      let i = tb; while (i >= 1) { if (nc[i] !== 0) { tmc = maxc[i - 1]; break; } i--; }
      if (i >= 1) { dsc = tb + 1; for (let j = tb + 1; j <= maxcs; j++) if (nc[j] !== 0) { dsc = j; break; } }
    }
    maxc[16] = M32; vp[16] = 0xFFFFF;
    this.tb = tb; this.tmc = tmc; this.dsc = dsc; this.maxc = maxc; this.vp = vp; this.lookup = lookup; this.order = order; return true;
  }
}
class Codec {
  start(buf) { this.buf = buf; this.pos = 0; this.bb = 0; this.bc = 0; }
  byte() { return this.pos < this.buf.length ? this.buf[this.pos++] : 0; }
  getBits(n) {
    while (this.bc < n) { const c = this.byte(); this.bc += 8; this.bb = (this.bb | (c << (32 - this.bc))) >>> 0; }
    const r = this.bb >>> (32 - n); this.bb = (this.bb << n) >>> 0; this.bc -= n; return r;
  }
  bits(n) { if (n === 0) return 0; if (n > 16) { const a = this.getBits(n - 16), b = this.getBits(16); return a * 65536 + b; } return this.getBits(n); }
  decode(m) {
    if (this.bc < 24) {
      if (this.bc < 16) { const c0 = this.byte(), c1 = this.byte(); this.bc += 16; this.bb = (this.bb | (((c0 << 8) | c1) << (32 - this.bc))) >>> 0; }
      else { const c = this.byte(); this.bc += 8; this.bb = (this.bb | (c << (32 - this.bc))) >>> 0; }
    }
    const bb = this.bb, k = (bb >>> 16) + 1; let sym, ln;
    if (k <= m.tmc) {
      const t = m.lookup[bb >>> (32 - m.tb)]; if (t === M32) throw new Error('crunch: bad code'); sym = t & 0xFFFF; ln = t >>> 16;
    } else {
      ln = m.dsc; const mc = m.maxc; while (k > mc[ln - 1]) ln++;
      const vp = m.vp[ln - 1] + (bb >>> (32 - ln)); if (vp >= m.total) throw new Error('crunch: bad ptr'); sym = m.order[vp];
    }
    this.bb = (bb << ln) >>> 0; this.bc -= ln; return sym;
  }
  model(m) {
    const total = this.bits(14); m.cs = new Array(total).fill(0); const ns = this.bits(5);
    if (ns < 1 || ns > 21) throw new Error('crunch: bad table'); const dm = new Model(); dm.cs = new Array(21).fill(0);
    for (let i = 0; i < ns; i++) dm.cs[MOST[i]] = this.bits(3);
    if (!dm.prepare()) throw new Error('crunch: dm'); let ofs = 0;
    while (ofs < total) {
      const rem = total - ofs, code = this.decode(dm);
      if (code <= 16) { m.cs[ofs++] = code; }
      else if (code === 17) { const l = this.bits(3) + 3; if (l > rem) throw new Error('crunch: run'); ofs += l; }
      else if (code === 18) { const l = this.bits(7) + 11; if (l > rem) throw new Error('crunch: run'); ofs += l; }
      else if (code === 19 || code === 20) {
        const l = code === 19 ? this.bits(2) + 3 : this.bits(6) + 7; if (ofs === 0 || l > rem) throw new Error('crunch: rep');
        const pv = m.cs[ofs - 1]; if (pv === 0) throw new Error('crunch: rep0'); for (let i = 0; i < l; i++) m.cs[ofs + i] = pv; ofs += l;
      } else throw new Error('crunch: code');
    }
    if (!m.prepare()) throw new Error('crunch: model');
  }
}
const u24 = (d, o) => (d[o] << 16) | (d[o + 1] << 8) | d[o + 2], u16 = (d, o) => (d[o] << 8) | d[o + 1], u32b = (d, o) => ((d[o] << 24) | (d[o + 1] << 16) | (d[o + 2] << 8) | d[o + 3]) >>> 0;
// returns {W,H,blocks,bs(block bytes: 8 or 16)}
function unpackCrunch(d, level) {
  level = level || 0;
  if (d[0] !== 0x48 || d[1] !== 0x78) throw new Error('Crunch header not found');
  const fmt = d[18]; if (fmt !== 10 && fmt !== 11 && fmt !== 12) throw new Error('Unsupported Crunch format ' + fmt);
  const alpha = fmt === 12, size = u32b(d, 6), w = u16(d, 12), h = u16(d, 14), levels = d[16];
  const ce = [u24(d, 33), u24(d, 36), u16(d, 39)], cs = [u24(d, 41), u24(d, 44), u16(d, 47)], ae = [u24(d, 49), u24(d, 52), u16(d, 55)], as = [u24(d, 57), u24(d, 60), u16(d, 63)];
  const ts = u16(d, 65), to = u24(d, 67), cdc = new Codec(); cdc.start(d.subarray(to, to + ts));
  const refDm = new Model(), ed = [new Model(), new Model()], sd = [new Model(), new Model()];
  cdc.model(refDm); cdc.model(ed[0]); cdc.model(sd[0]); if (alpha) { cdc.model(ed[1]); cdc.model(sd[1]); }
  const nce = ce[2]; cdc.start(d.subarray(ce[0], ce[0] + ce[1])); let dm = new Model(); cdc.model(dm);
  const cep = new Uint32Array(nce); let a = 0;
  for (let i = 0; i < nce; i++) { for (let b = 0; b < 32; b += 8) a = (a + (cdc.decode(dm) << b)) | 0; a &= 0x1F1F1F1F; cep[i] = a; }
  const ncs = cs[2]; cdc.start(d.subarray(cs[0], cs[0] + cs[1])); dm = new Model(); cdc.model(dm);
  const csel = new Uint32Array(ncs << 1); let s = 0;
  for (let i = 0; i < ncs; i++) {
    for (let j = 0; j < 32; j += 4) s ^= cdc.decode(dm) << j;
    const sel = (((~s) & 0xAAAAAAAA) | ((~(s ^ (s >>> 1))) & 0x55555555)) >>> 0; let t = 8;
    for (let hh = 0; hh < 4; hh++) { for (let ww = 0; ww < 4; ww++) {
      const s0 = sel >>> ((ww << 3) | (hh << 1)); csel[i << 1] |= (((s0 >>> 1) & 1) | ((s0 & 1) << 16)) << (t & 15);
      const s1 = sel >>> ((hh << 3) | (ww << 1)); csel[(i << 1) | 1] |= (((s1 >>> 1) & 1) | ((s1 & 1) << 16)) << (t & 15); t += 4;
    } t -= 15; }
  }
  let aep, asel;
  if (alpha) {
    const nae = ae[2]; cdc.start(d.subarray(ae[0], ae[0] + ae[1])); dm = new Model(); cdc.model(dm); aep = new Uint8Array(nae * 2); let aa = 0, ab = 0;
    for (let i = 0; i < nae; i++) { const sa = cdc.decode(dm), sb = cdc.decode(dm); aa = (sa + aa) & 255; ab = (sb + ab) & 255; aep[i * 2] = aa; aep[i * 2 + 1] = ab; }
    const nas = as[2]; cdc.start(d.subarray(as[0], as[0] + as[1])); dm = new Model(); cdc.model(dm);
    const ab8 = new Uint8Array((nas * 6 + 1) * 2), sl = new Uint8Array(8); let dp = 0;
    for (let i = 0; i < nas; i++) {
      let sg = 0;
      for (let p = 0; p < 16; p++) {
        if (p & 1) sg >>= 3; else { sl[p >> 1] ^= cdc.decode(dm) & 255; sg = sl[p >> 1]; }
        let sv = sg & 7; if (sv <= 3) sv = 3 - sv;
        let dd = 3 * (p + 1), bo = dd >> 3, bi = dd & 7; ab8[dp + bo] |= (sv << (8 - bi)) & 255; if (bi < 3) ab8[dp + bo - 1] |= sv >> bi;
        dd += 9 * ((p & 3) - (p >> 2)); bo = dd >> 3; bi = dd & 7; ab8[dp + bo + 6] |= (sv << (8 - bi)) & 255; if (bi < 3) ab8[dp + bo + 5] |= sv >> bi;
      }
      dp += 12;
    }
    asel = new Uint16Array(ab8.length >> 1); for (let k = 0; k < asel.length; k++) asel[k] = ab8[2 * k] | (ab8[2 * k + 1] << 8);
  }
  const lo = u32b(d, 70 + 4 * level), end = level + 1 < levels ? u32b(d, 70 + 4 * (level + 1)) : size;
  cdc.start(d.subarray(lo, end)); const W = Math.max(1, w >> level), H = Math.max(1, h >> level);
  const bx = (W + 3) >> 2, by = (H + 3) >> 2, wd = (bx + 1) & ~1, ht = (by + 1) & ~1, bs = alpha ? 16 : 8;
  const out = new Uint8Array(bx * by * bs), odv = new DataView(out.buffer);
  const er = new Uint8Array(wd), c0 = new Int32Array(wd), c1 = new Int32Array(wd), a0 = new Int32Array(wd), a1 = new Int32Array(wd);
  let cei = 0, aei = 0, dc = 0, da = 0; const nae = alpha ? ae[2] : 0;
  for (let y = 0; y < ht; y++) for (let x = 0; x < wd; x++) {
    let epr;
    if (y & 1) epr = er[x]; else { const rg = cdc.decode(refDm); epr = (rg & 3) | ((rg >> 2) & 12); er[x] = ((rg >> 2) & 3) | ((rg >> 4) & 12); }
    const k = epr & 3;
    if (k === 0) { cei += cdc.decode(ed[0]); if (cei >= nce) cei -= nce; c0[x] = cei; if (alpha) { aei += cdc.decode(ed[1]); if (aei >= nae) aei -= nae; a0[x] = aei; } }
    else if (k === 1) { c0[x] = cei; a0[x] = aei; }
    else if (k === 3) { cei = dc; c0[x] = cei; aei = da; a0[x] = aei; }
    else { cei = c0[x]; aei = a0[x]; }
    epr >>= 2; const e0 = cep[cei]; const sl = cdc.decode(sd[0]); let asi = 0; if (alpha) asi = cdc.decode(sd[1]);
    if (epr !== 0) { cei += cdc.decode(ed[0]); if (cei >= nce) cei -= nce; }
    dc = c1[x]; da = a1[x]; c1[x] = cei; a1[x] = aei; const e1 = cep[cei];
    if (x < bx && y < by) {
      const flip = (epr >> 1) ^ 1; let diff = 1;
      for (let c = 0; c < 3; c++) { const p0 = (e0 >>> (c * 8)) & 255, p1 = (e1 >>> (c * 8)) & 255; if (!(p0 + 3 >= p1 && p1 + 4 >= p0)) { diff = 0; break; } }
      const o = (y * bx + x) * bs + (alpha ? 8 : 0);
      for (let c = 0; c < 3; c++) {
        const p0 = (e0 >>> (c * 8)) & 255, p1 = (e1 >>> (c * 8)) & 255;
        out[o + c] = diff ? ((p0 << 3) | ((p1 - p0) & 7)) & 255 : ((p0 << 3) & 0xF0) | (p1 >> 1);
      }
      out[o + 3] = (((e0 >>> 24) << 5) | ((e1 >>> 24) << 2) | (diff << 1) | flip) & 255; odv.setUint32(o + 4, csel[(sl << 1) | flip], true);
      if (alpha) { const ob = (y * bx + x) * 16, base = asi * 6 + (flip ? 3 : 0); out[ob] = aep[aei * 2]; out[ob + 1] = aep[aei * 2 + 1]; odv.setUint16(ob + 2, asel[base], true); odv.setUint16(ob + 4, asel[base + 1], true); odv.setUint16(ob + 6, asel[base + 2], true); }
    }
  }
  return { W, H, blocks: out, bs, alpha };
}
// ---------------- ETC1/ETC2/EAC block decoders ----------------
const T1 = [[2, 8], [5, 17], [9, 29], [13, 42], [18, 60], [24, 80], [33, 106], [47, 183]], DIST = [3, 6, 11, 16, 23, 32, 41, 64];
const EAC = [[-3,-6,-9,-15,2,5,8,14],[-3,-7,-10,-13,2,6,9,12],[-2,-5,-8,-13,1,4,7,12],[-2,-4,-6,-13,1,3,5,12],[-3,-6,-8,-12,2,5,7,11],[-3,-7,-9,-11,2,6,8,10],[-4,-7,-8,-11,3,6,7,10],[-3,-5,-8,-11,2,4,7,10],[-2,-6,-8,-10,1,5,7,9],[-2,-5,-8,-10,1,4,7,9],[-2,-4,-8,-10,1,3,7,9],[-2,-5,-7,-10,1,4,6,9],[-3,-4,-7,-10,2,3,6,9],[-1,-2,-3,-10,0,1,2,9],[-4,-6,-8,-9,3,5,7,8],[-3,-5,-7,-9,2,4,6,8]];
const REV = [15, 11, 7, 3, 14, 10, 6, 2, 13, 9, 5, 1, 12, 8, 4, 0];
const cl = v => v < 0 ? 0 : (v > 255 ? 255 : v);
function etcRGB(d, o, out) { // out: Uint8Array(48), index (y*4+x)*3
  const d0 = d[o], d1 = d[o + 1], d2 = d[o + 2], d3 = d[o + 3], j = (d[o + 6] << 8) | d[o + 7], k = (d[o + 4] << 8) | d[o + 5];
  const put = (n, r, g, b) => { const q = ((n & 3) * 4 + (n >> 2)) * 3; out[q] = r; out[q + 1] = g; out[q + 2] = b; };
  let c0, c1;
  if (d3 & 2) {
    const r = d0 & 0xf8, dr = ((d0 << 3) & 0x18) - ((d0 << 3) & 0x20), g = d1 & 0xf8, dg = ((d1 << 3) & 0x18) - ((d1 << 3) & 0x20), b = d2 & 0xf8, db = ((d2 << 3) & 0x18) - ((d2 << 3) & 0x20);
    if (r + dr < 0 || r + dr > 255) {
      const a = [((d0 << 3) & 0xc0) | ((d0 << 4) & 0x30) | ((d0 >> 1) & 0xc) | (d0 & 3), (d1 & 0xf0) | (d1 >> 4), (d1 & 0x0f) | ((d1 << 4) & 0xFF)];
      const c = [(d2 & 0xf0) | (d2 >> 4), (d2 & 0x0f) | ((d2 << 4) & 0xFF), (d3 & 0xf0) | (d3 >> 4)], dd = DIST[((d3 >> 1) & 6) | (d3 & 1)];
      const cs = [a, [cl(c[0] + dd), cl(c[1] + dd), cl(c[2] + dd)], c, [cl(c[0] - dd), cl(c[1] - dd), cl(c[2] - dd)]];
      for (let n = 0; n < 16; n++) { const p = cs[(((k >> n) & 1) << 1) | ((j >> n) & 1)]; put(n, p[0], p[1], p[2]); } return;
    }
    if (g + dg < 0 || g + dg > 255) {
      const a = [((d0 << 1) & 0xf0) | ((d0 >> 3) & 0xf), ((d0 << 5) & 0xe0) | (d1 & 0x10), 0]; a[1] |= a[1] >> 4; a[2] = (d1 & 8) | ((d1 << 1) & 6) | (d2 >> 7); a[2] |= (a[2] << 4) & 0xFF;
      const c = [((d2 << 1) & 0xf0) | ((d2 >> 3) & 0xf), ((d2 << 5) & 0xe0) | ((d3 >> 3) & 0x10), 0]; c[1] |= c[1] >> 4; c[2] = ((d3 << 1) & 0xf0) | ((d3 >> 3) & 0xf);
      let di = (d3 & 4) | ((d3 << 1) & 2); if (a[0] > c[0] || (a[0] === c[0] && (a[1] > c[1] || (a[1] === c[1] && a[2] >= c[2])))) di++; const dd = DIST[di];
      const cs = [[cl(a[0] + dd), cl(a[1] + dd), cl(a[2] + dd)], [cl(a[0] - dd), cl(a[1] - dd), cl(a[2] - dd)], [cl(c[0] + dd), cl(c[1] + dd), cl(c[2] + dd)], [cl(c[0] - dd), cl(c[1] - dd), cl(c[2] - dd)]];
      for (let n = 0; n < 16; n++) { const p = cs[(((k >> n) & 1) << 1) | ((j >> n) & 1)]; put(n, p[0], p[1], p[2]); } return;
    }
    if (b + db < 0 || b + db > 255) {
      const O = [((d0 << 1) & 0xfc) | ((d0 >> 5) & 3), ((d0 << 7) & 0x80) | (d1 & 0x7e) | (d0 & 1), 0]; O[2] = ((d1 << 7) & 0x80) | ((d2 << 2) & 0x60) | ((d2 << 3) & 0x18) | ((d3 >> 5) & 4); O[2] |= O[2] >> 6;
      const Hh = [((d3 << 1) & 0xf8) | ((d3 << 2) & 4) | ((d3 >> 5) & 3), (d[o + 4] & 0xfe) | (d[o + 4] >> 7), 0]; Hh[2] = ((d[o + 4] << 7) & 0x80) | ((d[o + 5] >> 1) & 0x7c); Hh[2] |= Hh[2] >> 6;
      const d5 = d[o + 5], d6 = d[o + 6], d7 = d[o + 7];
      const V = [((d5 << 5) & 0xe0) | ((d6 >> 3) & 0x1c) | ((d5 >> 1) & 3), ((d6 << 3) & 0xf8) | ((d7 >> 5) & 6) | ((d6 >> 4) & 1), ((d7 << 2) & 0xFF) | ((d7 >> 4) & 3)];
      for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) { const q = (y * 4 + x) * 3; for (let c = 0; c < 3; c++) out[q + c] = cl((x * (Hh[c] - O[c]) + y * (V[c] - O[c]) + 4 * O[c] + 2) >> 2); } return;
    }
    c0 = [r | (r >> 5), g | (g >> 5), b | (b >> 5)]; c1 = [(r + dr) & 255, (g + dg) & 255, (b + db) & 255]; c1 = [c1[0] | (c1[0] >> 5), c1[1] | (c1[1] >> 5), c1[2] | (c1[2] >> 5)];
  } else {
    c0 = [(d0 & 0xf0) | (d0 >> 4), (d1 & 0xf0) | (d1 >> 4), (d2 & 0xf0) | (d2 >> 4)]; c1 = [(d0 & 0x0f) | ((d0 << 4) & 255), (d1 & 0x0f) | ((d1 << 4) & 255), (d2 & 0x0f) | ((d2 << 4) & 255)];
  }
  const codes = [d3 >> 5, (d3 >> 2) & 7], flip = d3 & 1;
  for (let n = 0; n < 16; n++) {
    const s = flip ? ((n >> 1) & 1) : (n >> 3); let m = T1[codes[s]][(j >> n) & 1]; if ((k >> n) & 1) m = -m; const c = s ? c1 : c0; put(n, cl(c[0] + m), cl(c[1] + m), cl(c[2] + m));
  }
}
function eacAlpha(d, o, out) { // out: Uint8Array(16) row-major
  const base = d[o], mult = d[o + 1] >> 4; if (mult === 0) { out.fill(base); return; }
  const tb = EAC[d[o + 1] & 15]; let hi = (d[o + 2] << 8) | d[o + 3], lo = ((d[o + 4] << 24) | (d[o + 5] << 16) | (d[o + 6] << 8) | d[o + 7]) >>> 0;
  const bits = BigInt(hi) * 4294967296n + BigInt(lo);
  for (let i = 0; i < 16; i++) out[REV[i]] = cl(base + mult * tb[Number((bits >> BigInt(3 * i)) & 7n)]);
}
// blocks -> RGBA (top-down)
function blocksToRGBA(W, H, blocks, kind) { // kind: 'etc1' (8B) | 'etc2a' (16B, alpha first)
  const bx = (W + 3) >> 2, by = (H + 3) >> 2, img = new Uint8ClampedArray(W * H * 4), px = new Uint8Array(48), al = new Uint8Array(16), bs = kind === 'etc2a' ? 16 : 8;
  for (let j = 0; j < by; j++) for (let i = 0; i < bx; i++) {
    const o = (j * bx + i) * bs; etcRGB(blocks, o + (bs === 16 ? 8 : 0), px); if (bs === 16) eacAlpha(blocks, o, al);
    for (let y = 0; y < 4; y++) { const yy = j * 4 + y; if (yy >= H) break; const row = H - 1 - yy;
      for (let x = 0; x < 4; x++) { const xx = i * 4 + x; if (xx >= W) break; const q = (row * W + xx) * 4, s = (y * 4 + x) * 3; img[q] = px[s]; img[q + 1] = px[s + 1]; img[q + 2] = px[s + 2]; img[q + 3] = bs === 16 ? al[y * 4 + x] : 255; } }
  }
  return img;
}
const FMT = { 1: 'Alpha8', 3: 'RGB24', 4: 'RGBA32', 14: 'BGRA32', 34: 'ETC1', 45: 'ETC2 RGB', 47: 'ETC2 RGBA', 64: 'Crunch ETC1', 65: 'Crunch ETC2A' };
function decodeTexture(b, t) {
  const raw = rawOf(b, t), W = t.w, H = t.h;
  if (W <= 0 || H <= 0 || raw.length === 0) throw new Error('This texture has no image data');
  if (raw[0] === 0x48 && raw[1] === 0x78 && (t.fmt === 64 || t.fmt === 65 || t.fmt === 28 || t.fmt === 29)) { const r = unpackCrunch(raw, 0); return { W: r.W, H: r.H, rgba: blocksToRGBA(r.W, r.H, r.blocks, r.alpha ? 'etc2a' : 'etc1') }; }
  const need = (w, h, bpp) => ((w + 3) >> 2) * ((h + 3) >> 2) * bpp;
  if (t.fmt === 34 || t.fmt === 45) return { W, H, rgba: blocksToRGBA(W, H, raw.subarray(0, need(W, H, 8)), 'etc1') };
  if (t.fmt === 47) return { W, H, rgba: blocksToRGBA(W, H, raw.subarray(0, need(W, H, 16)), 'etc2a') };
  const img = new Uint8ClampedArray(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const q = ((H - 1 - y) * W + x) * 4; let s;
    if (t.fmt === 4) { s = (y * W + x) * 4; img[q] = raw[s]; img[q + 1] = raw[s + 1]; img[q + 2] = raw[s + 2]; img[q + 3] = raw[s + 3]; }
    else if (t.fmt === 14) { s = (y * W + x) * 4; img[q] = raw[s + 2]; img[q + 1] = raw[s + 1]; img[q + 2] = raw[s]; img[q + 3] = raw[s + 3]; }
    else if (t.fmt === 3) { s = (y * W + x) * 3; img[q] = raw[s]; img[q + 1] = raw[s + 1]; img[q + 2] = raw[s + 2]; img[q + 3] = 255; }
    else if (t.fmt === 1) { s = y * W + x; img[q] = img[q + 1] = img[q + 2] = 255; img[q + 3] = raw[s]; }
    else throw new Error('Format ' + (FMT[t.fmt] || t.fmt) + ' is not supported yet');
  }
  return { W, H, rgba: img };
}
// ---------------- ETC1 encoder ----------------
function encodeETC1(rgba, W, H) { // rgba top-down, W,H multiples of 4; returns blocks in Unity (bottom-up) order
  const bx = W >> 2, by = H >> 2, out = new Uint8Array(bx * by * 8), px = new Float32Array(48);
  const MODS = T1.map(([s, b]) => [s, b, -s, -b]);
  for (let j = 0; j < by; j++) for (let i = 0; i < bx; i++) {
    for (let y = 0; y < 4; y++) { const row = H - 1 - (j * 4 + y); for (let x = 0; x < 4; x++) { const s = (row * W + i * 4 + x) * 4, a = rgba[s + 3] / 255, q = (x * 4 + y) * 3; px[q] = rgba[s] * a + 255 * (1 - a); px[q + 1] = rgba[s + 1] * a + 255 * (1 - a); px[q + 2] = rgba[s + 2] * a + 255 * (1 - a); } }
    let bestErr = 1e18, bestBytes = null;
    for (let flip = 0; flip < 2; flip++) {
      const subs = [[], []]; for (let n = 0; n < 16; n++) { const x = n >> 2, y = n & 3; subs[(flip ? y >= 2 : x >= 2) ? 1 : 0].push(n); }
      const mean = [[0, 0, 0], [0, 0, 0]];
      for (let s = 0; s < 2; s++) { for (const n of subs[s]) for (let c = 0; c < 3; c++) mean[s][c] += px[n * 3 + c]; for (let c = 0; c < 3; c++) mean[s][c] /= 8; }
      const q5 = mean.map(m => m.map(v => Math.min(31, Math.max(0, Math.round(v * 31 / 255))))), q4 = mean.map(m => m.map(v => Math.min(15, Math.max(0, Math.round(v / 17)))));
      let diff = true; for (let c = 0; c < 3; c++) { const dl = q5[1][c] - q5[0][c]; if (dl < -4 || dl > 3) diff = false; }
      let tot = 0; const tbl = [0, 0], idx = [new Uint8Array(16), new Uint8Array(16)];
      for (let s = 0; s < 2; s++) {
        const base = diff ? q5[s].map(v => (v << 3) | (v >> 2)) : q4[s].map(v => v * 17); let be = 1e18;
        for (let t = 0; t < 8; t++) {
          let e = 0; const ti = new Uint8Array(16);
          for (const n of subs[s]) {
            let bd = 1e18, bi = 0;
            for (let m = 0; m < 4; m++) { const mv = MODS[t][m]; let dd = 0; for (let c = 0; c < 3; c++) { const df = px[n * 3 + c] - cl(base[c] + mv); dd += df * df; } if (dd < bd) { bd = dd; bi = m; } }
            e += bd; ti[n] = bi;
          }
          if (e < be) { be = e; tbl[s] = t; idx[s] = ti; }
        }
        tot += be;
      }
      if (tot < bestErr) {
        bestErr = tot; const b = new Uint8Array(8);
        for (let c = 0; c < 3; c++) b[c] = diff ? ((q5[0][c] << 3) | ((q5[1][c] - q5[0][c]) & 7)) : ((q4[0][c] << 4) | q4[1][c]);
        b[3] = (tbl[0] << 5) | (tbl[1] << 2) | ((diff ? 1 : 0) << 1) | flip;
        let V = 0; for (let n = 0; n < 16; n++) { const s = (flip ? (n & 3) >= 2 : (n >> 2) >= 2) ? 1 : 0, v = idx[s][n]; V |= (((v >> 1) & 1) << (16 + n)) | ((v & 1) << n); }
        V >>>= 0; b[4] = V >>> 24; b[5] = (V >>> 16) & 255; b[6] = (V >>> 8) & 255; b[7] = V & 255; bestBytes = b;
      }
    }
    out.set(bestBytes, (j * bx + i) * 8);
  }
  return out;
}
function toRGBA32(rgba, W, H) { const o = new Uint8Array(W * H * 4); for (let y = 0; y < H; y++) { const sr = H - 1 - y; for (let x = 0; x < W; x++) { const s = (sr * W + x) * 4, q = (y * W + x) * 4; o[q] = rgba[s]; o[q + 1] = rgba[s + 1]; o[q + 2] = rgba[s + 2]; o[q + 3] = rgba[s + 3]; } } return o; }
// ---------------- replace + write ----------------
function replaceTexture(b, t, rgba) { // rgba: W x H (t.w x t.h), top-down
  const W = t.w, H = t.h; let fmt, data;
  if (t.fmt === 64 || t.fmt === 34 || t.fmt === 45) { if ((W | H) & 3) throw new Error('Texture size is not a multiple of 4'); fmt = 34; data = encodeETC1(rgba, W, H); }
  else if (t.fmt === 65 || t.fmt === 47 || t.fmt === 4 || t.fmt === 14) { fmt = 4; data = toRGBA32(rgba, W, H); }
  else throw new Error('Replacing this texture format (' + (FMT[t.fmt] || t.fmt) + ') is not supported yet');
  const old = b.sf.subarray(t.bs, t.bs + t.size), head = old.slice(0, t.imgPos), hd = new DataView(head.buffer);
  hd.setInt32(t.q + 8, data.length, true); hd.setInt32(t.q + 12, 0, true); hd.setInt32(t.q + 16, fmt, true); hd.setInt32(t.q + 20, 1, true);
  const pad = (4 - (data.length & 3)) & 3, tail = new Uint8Array(4 + data.length + pad + 16); new DataView(tail.buffer).setInt32(0, data.length, true); tail.set(data, 4);
  const obj = concat([head, tail]), start = (b.sf.length + 7) & ~7, nsf = new Uint8Array(start + obj.length); nsf.set(b.sf); nsf.set(obj, start);
  const dv = new DataView(nsf.buffer), p = parseSF({ sf: b.sf }); // header info
  dv.setBigInt64(p.sizePos, BigInt(nsf.length)); dv.setBigInt64(t.entry + 8, BigInt(start - p.doff), p.le); dv.setUint32(t.entry + 16, obj.length, p.le);
  b.sf = nsf; b.nodes[0].size = nsf.length; let off = nsf.length; for (let i = 1; i < b.nodes.length; i++) { b.nodes[i].off = off; off += b.nodes[i].size; }
  if (b.changed.indexOf(t.name) < 0) b.changed.push(t.name);
}
function writeBundle(b) {
  const data = concat([b.sf, b.res]), enc = new TextEncoder(); let bi = [new Uint8Array(16)];
  const parts = []; const w = (n, f) => { const a = new Uint8Array(n); f(new DataView(a.buffer)); parts.push(a); };
  w(4, d => d.setInt32(0, 1)); w(10, d => { d.setUint32(0, data.length); d.setUint32(4, data.length); d.setUint16(8, 0); }); w(4, d => d.setInt32(0, b.nodes.length));
  for (const n of b.nodes) { w(20, d => { d.setBigUint64(0, BigInt(n.off)); d.setBigUint64(8, BigInt(n.size)); d.setUint32(16, n.flags); }); parts.push(enc.encode(n.path), new Uint8Array(1)); }
  const info = concat(bi.concat(parts)), flags = 0x240;
  const head = concat([enc.encode('UnityFS'), new Uint8Array(1), new Uint8Array([0, 0, 0, b.ver]), b.strings]);
  const hdrEnd = head.length + 20, pad1 = (16 - (hdrEnd % 16)) % 16, posBi = hdrEnd + pad1, dataPos = (posBi + info.length + 15) & ~15, total = dataPos + data.length;
  const fixed = new Uint8Array(20), fd = new DataView(fixed.buffer); fd.setBigUint64(0, BigInt(total)); fd.setUint32(8, info.length); fd.setUint32(12, info.length); fd.setUint32(16, flags);
  return concat([b.prefix, head, fixed, new Uint8Array(pad1), info, new Uint8Array(dataPos - posBi - info.length), data]);
}
function listTextures(b) { return parseSF(b).texs; }
return { openBundle, listTextures, decodeTexture, replaceTexture, writeBundle, rawOf, FMT, unpackCrunch, blocksToRGBA, encodeETC1, lz4, lzma, parseSF };
});
