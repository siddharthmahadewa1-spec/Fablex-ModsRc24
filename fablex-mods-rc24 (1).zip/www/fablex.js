(function () {
'use strict';
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)], { makeZip, saveFile, toCanvas, pngBytes, tick } = U;
let bundle = null, orig = null, fname = '', texs = [], cur = null, filt = 'all', pend = null;
let favs = new Set(); try { favs = new Set(JSON.parse(localStorage.getItem('fx_favs') || '[]')); } catch (e) {}
const busy = m => { $('#busy').classList.toggle('on', !!m); if (m) $('#busyt').textContent = m; };
const mb = n => (n / 1048576).toFixed(1) + ' MB', clean = n => n.replace(/[^A-Za-z0-9._-]+/g, '_'), say = m => { $('#msg').textContent = m || ''; };
const logs = []; function log(m) { logs.unshift(new Date().toLocaleTimeString() + '  ' + m); logs.length = Math.min(logs.length, 12); $('#log').innerHTML = logs.map(l => '<div class="ln"><span class="mu">' + l.replace(/</g, '&lt;') + '</span></div>').join(''); }
function show(v) { $$('section').forEach(s => s.hidden = s.id !== 'v-' + v); $$('nav button').forEach(b => b.classList.toggle('on', b.dataset.v === v)); window.scrollTo(0, 0); }
$$('nav button').forEach(b => b.onclick = () => show(b.dataset.v));
// ---- thumbnails ----
const queue = []; let running = false;
async function thumbs() { if (running) return; running = true; while (queue.length) { const { t, cv } = queue.shift(); try { const src = toCanvas(RC.decodeTexture(bundle, t)), x = cv.getContext('2d'); x.drawImage(src, 0, 0, cv.width, cv.height); } catch (e) { cv.getContext('2d').fillStyle = '#263244'; cv.getContext('2d').fillRect(0, 0, cv.width, cv.height); } await tick(); } running = false; }
const io = new IntersectionObserver(es => { for (const e of es) if (e.isIntersecting) { io.unobserve(e.target); queue.push(e.target._j); } if (queue.length) thumbs(); }, { rootMargin: '300px' });
function summary() { const f = {}; texs.forEach(t => { const k = RC.FMT[t.fmt] || 'fmt ' + t.fmt; f[k] = (f[k] || 0) + 1; }); $('#info').innerHTML = '<b class="fn">' + fname + '</b><div class="tiles"><div><b>' + texs.length + '</b><span>Textures</span></div><div><b>' + mb(orig.length).replace(' MB', '') + '</b><span>MB</span></div><div><b>' + bundle.changed.length + '</b><span>Modified</span></div></div><div class="fmts">' + Object.entries(f).map(e => '<span>' + e[0] + ' · ' + e[1] + '</span>').join('') + '</div>'; $('#save').disabled = !bundle.changed.length; }
function grid() {
  const q = $('#q').value.trim().toLowerCase(), g = $('#grid'); g.innerHTML = ''; queue.length = 0; let n = 0;
  for (const t of texs) {
    const ch = bundle && bundle.changed.indexOf(t.name) >= 0;
    if ((q && t.name.toLowerCase().indexOf(q) < 0) || (filt === 'fav' && !favs.has(t.name)) || (filt === 'chg' && !ch)) continue; n++;
    const c = document.createElement('button'); c.className = 'card' + (ch ? ' chg' : '') + (favs.has(t.name) ? ' isfav' : ''); c.innerHTML = '<div class="th"><canvas width="128" height="128"></canvas><i class="fv">★</i><i class="dot"></i></div><b></b><span class="sm"></span>';
    c.querySelector('b').textContent = t.name.replace(/^Uniform_/, ''); c.querySelector('.sm').textContent = t.w + '×' + t.h + ' · ' + (RC.FMT[t.fmt] || t.fmt);
    const cv = c.querySelector('canvas'); cv._j = { t, cv }; io.observe(cv); c.onclick = () => open(t); g.appendChild(c);
  }
  $('#none').hidden = n > 0; $('#none').querySelector('div').textContent = bundle ? 'No textures found.' : 'Open a bundle file in Files first.';
}
async function open(t) {
  try { busy('Opening texture...'); await tick(); const r = RC.decodeTexture(bundle, t), cv = $('#cv'); cv.width = r.W; cv.height = r.H; cv.getContext('2d').drawImage(toCanvas(r), 0, 0); cur = t; $('#st').textContent = t.name; $('#sm').textContent = t.w + '×' + t.h + ' · ' + (RC.FMT[t.fmt] || t.fmt); $('#sf').textContent = favs.has(t.name) ? 'Favourite hatao' : 'Favourite'; $('#sheet').classList.add('on'); }
  catch (e) { say('Error: ' + e.message); show('files'); }
  busy(false);
}
$('#sc').onclick = () => $('#sheet').classList.remove('on');
$('#sf').onclick = () => { favs.has(cur.name) ? favs.delete(cur.name) : favs.add(cur.name); try { localStorage.setItem('fx_favs', JSON.stringify([...favs])); } catch (e) {} $('#sf').textContent = favs.has(cur.name) ? 'Favourite hatao' : 'Favourite'; grid(); };
$('#sp').onclick = async () => { try { busy('Creating PNG...'); await tick(); say(await saveFile(clean(cur.name) + '.png', await pngBytes(toCanvas(RC.decodeTexture(bundle, cur))))); log('PNG saved: ' + cur.name); } catch (e) { say('Error: ' + e.message); } busy(false); };
$('#sr').onclick = () => { pend = cur; $('#img').click(); };
$('#img').onchange = async e => {
  const f = e.target.files[0], t = pend; e.target.value = ''; if (!f || !t) return;
  try {
    const url = URL.createObjectURL(f), im = new Image(); im.src = url; await im.decode();
    if (Math.abs(im.width / im.height - t.w / t.h) > 0.02 && !confirm('Image ' + im.width + '×' + im.height + ' but the texture is ' + t.w + '×' + t.h + '. The aspect ratio differs, so the image will be stretched. Continue?')) { URL.revokeObjectURL(url); return; }
    busy('Applying image (' + t.w + '×' + t.h + ')...'); await tick();
    const c = document.createElement('canvas'); c.width = t.w; c.height = t.h; const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(im, 0, 0, t.w, t.h); URL.revokeObjectURL(url); await tick();
    RC.replaceTexture(bundle, t, x.getImageData(0, 0, t.w, t.h).data); texs = RC.listTextures(bundle); log('Replaced: ' + t.name); say('"' + t.name + '" replaced. Tap "Save bundle" in Files.'); $('#sheet').classList.remove('on'); summary(); grid();
  } catch (err) { say('Error: ' + err.message); log('Replace failed: ' + err.message); }
  busy(false);
};
$$('.chip').forEach(c => c.onclick = () => { filt = c.dataset.f; $$('.chip').forEach(x => x.classList.toggle('on', x === c)); grid(); });
$('#q').oninput = grid;
// ---- files ----
$('#file').onchange = async e => {
  const f = e.target.files[0]; if (!f) return; busy('Opening file...'); await tick();
  try { orig = new Uint8Array(await f.arrayBuffer()); bundle = RC.openBundle(orig.slice()); fname = f.name; texs = RC.listTextures(bundle); $('#box').hidden = false; say(''); summary(); grid(); log('Opened: ' + fname + ' (' + texs.length + ' textures)'); if (!texs.length) say('No textures found in this file (it may be a data-only file).'); }
  catch (err) { $('#box').hidden = true; bundle = null; say(''); alert('This file could not be opened: ' + err.message + '\n(Only Unity bundle files are supported for now, not zip/OBB.)'); log('Open failed: ' + err.message); }
  busy(false); e.target.value = '';
};
$('#save').onclick = async () => {
  try { busy('Building the new bundle...'); await tick(); const out = RC.writeBundle(bundle); let m = ''; if ($('#bk').checked) { m = await saveFile(fname + '.original_backup', orig) + '\n'; }
    m += await saveFile(fname, out); say(m); log('Bundle saved: ' + fname + ' (' + mb(out.length) + ')'); } catch (e) { say('Save failed: ' + e.message); log('Save failed: ' + e.message); }
  busy(false);
};
$('#zip').onclick = async () => {
  try { const PART = 60; let part = 1, files = [], ok = 0, skip = 0, last = '';
    const flush = async () => { if (files.length) { last = await saveFile(clean(fname) + '_PNG' + (texs.length > PART ? '_part' + part : '') + '.zip', makeZip(files)); files = []; part++; } };
    for (let i = 0; i < texs.length; i++) { busy('Creating PNGs ' + (i + 1) + '/' + texs.length + '...'); await tick(); try { files.push({ name: clean(texs[i].name) + '.png', data: await pngBytes(toCanvas(RC.decodeTexture(bundle, texs[i]))) }); ok++; } catch (e) { skip++; } if (files.length >= PART) await flush(); }
    await flush(); say(ok + ' PNG exported' + (skip ? ', ' + skip + ' had no image' : '') + '. ' + last); log('Zip export: ' + ok + ' PNG');
  } catch (e) { say('Zip failed: ' + e.message); }
  busy(false);
};
// ---- converter ----
$('#cq').oninput = () => $('#cqv').textContent = $('#cq').value;
$('#cin').onchange = () => { $('#cgo').disabled = !$('#cin').files.length; $('#cmsg').textContent = $('#cin').files.length + ' images selected.'; };
$('#cgo').onclick = async () => {
  const fs = [...$('#cin').files], fmt = $('#cfmt').value, mx = +$('#cmax').value || 0, files = [];
  try { for (let i = 0; i < fs.length; i++) { busy('Converting ' + (i + 1) + '/' + fs.length + '...'); await tick();
      const url = URL.createObjectURL(fs[i]), im = new Image(); im.src = url; await im.decode(); let w = im.width, h = im.height; if (mx && Math.max(w, h) > mx) { const k = mx / Math.max(w, h); w = Math.round(w * k); h = Math.round(h * k); }
      const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); if (fmt === 'jpg') { x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); } x.imageSmoothingQuality = 'high'; x.drawImage(im, 0, 0, w, h); URL.revokeObjectURL(url);
      const b = await new Promise(r => c.toBlob(r, fmt === 'jpg' ? 'image/jpeg' : 'image/png', +$('#cq').value / 100)); files.push({ name: clean(fs[i].name.replace(/\.[^.]+$/, '')) + '.' + fmt, data: new Uint8Array(await b.arrayBuffer()) }); }
    const m = files.length === 1 ? await saveFile(files[0].name, files[0].data) : await saveFile('converted_' + fmt + '.zip', makeZip(files)); $('#cmsg').textContent = files.length + ' images converted. ' + m; log('Convert: ' + files.length + ' > ' + fmt);
  } catch (e) { $('#cmsg').textContent = 'Error: ' + e.message; }
  busy(false);
};
// ---- checker ----
$('#cgo2').onclick = async () => {
  if (!bundle) { $('#cres').innerHTML = '<span class="mu">Open a bundle file in Files first.</span>'; return; }
  const res = { ok: [], warn: [], err: [], empty: [] };
  for (let i = 0; i < texs.length; i++) { const t = texs[i]; if (i % 6 === 0) { busy('Checking ' + (i + 1) + '/' + texs.length + '...'); await tick(); }
    try { RC.decodeTexture(bundle, t); (t.fmt === 64 || t.fmt === 65 ? res.warn : res.ok).push(t.name); } catch (e) { (/no image data/.test(e.message) ? res.empty : res.err).push(t.name + ' — ' + e.message); } }
  busy(false); const row = (c, l, a, n) => '<div class="ln"><span class="st ' + c + '">' + l + '</span><span class="mu">' + a + '</span></div>';
  $('#cres').innerHTML = row('ok', 'Compatible', res.ok.length + ' textures (open fine, format stays the same when replaced)') + row('warn', 'Warning', res.warn.length + ' textures (Crunch: becomes ETC1/RGBA32 when replaced, file gets larger)') + row('err', 'Unsupported', res.err.length + ' texture') + row('err', 'Empty', res.empty.length + ' textures (no image data)') + (res.err.length ? '<div class="sm" style="margin-top:8px">' + res.err.slice(0, 30).join('<br>').replace(/</g, '&lt;') + '</div>' : '');
  log('Check: ' + res.ok.length + ' ok, ' + res.warn.length + ' warning, ' + res.err.length + ' unsupported');
};
grid();
})();
