FABLEX MODS - RC24 : APK banane ke steps (sirf phone se)
1. GitHub par naya repo banao (ya purana use karo).
2. fablex-mods-rc24.zip ko repo ke root mein upload karo (unzip mat karo).
3. ".github/workflows/build-apk.yml" naam ki file banao aur build-apk.yml ka text paste karo.
4. Actions -> "Build APK" -> Run workflow.
5. Artifacts se "FABLEX-MODS-RC24-APK" download karo, usme APK hai.
Bina APK ke turant try karne ke liye fablex_mods_rc24.html ko Chrome mein kholo.
